package org.jianghuan;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/logout")

public class LogoutServlet {
    public void doPost(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws ServletException, IOException {
        //System.out.println("logoutServlet is running......");
        HttpSession httpSession = httpServletRequest.getSession();
        httpSession.invalidate();
        httpServletRequest.getRequestDispatcher("./indexServlet").forward(httpServletRequest,httpServletResponse);
    }//删除用户的session信息并将请求重定向到IndexServlet访问网站首页
}
