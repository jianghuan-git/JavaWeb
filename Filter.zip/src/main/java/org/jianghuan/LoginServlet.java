package org.jianghuan;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet {
    public void doPost(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws IOException {
        //System.out.println("loginServlet is running......");
        String username = httpServletRequest.getParameter("username");
        String password = httpServletRequest.getParameter("password");
        HttpSession httpSession = httpServletRequest.getSession();
        if(username.equals("mhr") && password.equals("123")){
            httpSession.setAttribute("username",username);
            httpSession.setAttribute("password",password);
            httpServletResponse.sendRedirect("/welcome.html");
        }else{
            httpServletResponse.setContentType("text/html;charset=utf-8");
            httpServletResponse.getWriter().print("<script language='javascript'>alert('您输入的账号或密码错误，请重新输入。');</script>");
            httpServletResponse.sendRedirect("/login.html");
        }
    }
}
