package org.jianghuan;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
@WebFilter("/*")
public class LoginFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
            throws IOException, ServletException {
        //System.out.println("doFilter is running......");

        HttpServletRequest httpServletRequest = (HttpServletRequest) servletRequest;
        HttpServletResponse httpServletResponse = (HttpServletResponse) servletResponse;
        System.out.println("URL:"+ httpServletRequest.getRequestURI());
        HttpSession httpSession = httpServletRequest.getSession();
        String username = (String)httpSession.getAttribute("username");
        String uri = httpServletRequest.getRequestURI();
        if(uri.contains("login") || uri.contains("static") || uri.contains("register") || uri.contains("public")){
            filterChain.doFilter(servletRequest, servletResponse);
        }//如果访问的是登录页面或者注册页面或者静态公共资源，不进行过滤，直接允许请求通过
        else{
            if(username == null){
                httpServletResponse.sendRedirect("/login.html");
            }//如果用户未登录，将请求重定向到登录页面
            else{
                filterChain.doFilter(servletRequest, servletResponse);
            }//如果用户已登录，放行，允许继续访问
        }//如果访问的页面不属于以上情况，则检查用户的session中是否存在表示已登录的属性,如"user"属性
    }

    @Override
    public void destroy() {

    }
}
