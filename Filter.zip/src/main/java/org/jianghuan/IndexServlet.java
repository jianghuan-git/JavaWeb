package org.jianghuan;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/index")
public class IndexServlet extends HttpServlet {
    public void service(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws IOException, ServletException {
        //System.out.println("IndexServlet is running......");
        HttpSession httpSession = httpServletRequest.getSession();
        if(httpSession.getAttribute("user") != null){
            httpServletResponse.sendRedirect("/welcome.html");
        }
        else{
            httpServletRequest.getRequestDispatcher("./login").forward(httpServletRequest,httpServletResponse);
        }
    }
}
